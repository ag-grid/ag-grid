# AG Grid Figma design system preview

Welcome to the preview for the upcoming AG Grid Figma design system. We're excited for you to start designing with AG Grid in Figma, and can't wait to hear your thoughts. 

To start simply open the `AG-Grid-design-system-30-0-0-preview.fig` file in Figma. You'll find a getting started guide, documentation, and a tutorial video all within the design system file. For more information on importing files into Figma see this [Figma help article](https://help.figma.com/hc/en-us/articles/360041003114-Import-files-into-Figma).

You may also want to experiment with creating and exporting a custom AG Grid theme using Figma variables. Once you've exported your custom AG Grid theme from Figma you can use the included Node.js project `ag-grid-figma-variables-to-css/` to create a custom theme to try out with AG Grid in browser. 

For any questions, or to provide feedback please email lead UX designer Mark Durrant at [mark.durrant@ag-grid.com](mark.durrant@ag-grid.com). 